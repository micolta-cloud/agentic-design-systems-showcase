# Skill: Figma Metadata Extractor (Unified AI Intelligence & Pixel-Perfect Physics)

## Purpose
An authoritative, deterministic extraction protocol that queries Figma API / MCP for individual `COMPONENT_SET` nodes, resolves bound variable IDs against Design System Tokens (`Light.tokens.json`, `Dark.tokens.json`, `spacing.json`), and outputs both **Pixel-Perfect Visual Physics** and **Machine-Readable AI Behavioral Schemas** (`componentMetadata`).

---

## 1. The 4-Layer Extraction Architecture

```text
┌───────────────────────────────────────────────────────────────────────────┐
│ Layer 1: Topological DAG & Spatial Extraction                             │
│   • Spatial Bounding-Box Sorting (x,y coordinate visual order)            │
│   • Atom/Molecule Dependency Resolution (Bottom-Up Protocol)              │
├───────────────────────────────────────────────────────────────────────────┤
│ Layer 2: Pixel-Perfect Visual Physics (Vincent DS Rules)                │
│   • M3 State Layer Overlays (On-Color Transparent Overlays & Opacities)   │
│   • Focus Ring Geometry Specs (visualW+4 × visualH+4, -2px offset)        │
│   • Touch Target vs. Safe Area Radius/Padding Calculations                │
│   • Token Variable Resolution (Semantic Colors, Sizing, Radius)           │
├───────────────────────────────────────────────────────────────────────────┤
│ Layer 3: AI Behavioral & Contextual Schema (Dev Skill Rules)             │
│   • Machine-Readable TypeScript/JSON Schema (`componentMetadata`)         │
│   • Use Cases, Common Patterns & Anti-Patterns                            │
│   • Composition Slots, Traversal Tree & Parent Constraints                │
├───────────────────────────────────────────────────────────────────────────┤
│ Layer 4: Accessibility & Test Bench Contracts                            │
│   • WCAG 2.1 AA / AAA ARIA Roles & Roving Keyboard Navigation             │
│   • Visual Regression Assertions & Unit Test Contracts                    │
└───────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Layer 1 — Topological DAG & Spatial Extraction

1. **Spatial Bounding-Box Sorting (`x`, `y` coordinates):**
   - Sort child nodes by `absoluteBoundingBox.x` for horizontal layouts and `absoluteBoundingBox.y` for vertical layouts.
   - Guarantees visual 1:1 order (`left` $\rightarrow$ `right`, `top` $\rightarrow$ `bottom`) without raw z-stack array index bugs.

2. **Authoritative `componentPropertyDefinitions` Extraction:**
   - Query `componentPropertyDefinitions` directly from `COMPONENT_SET` nodes to pull exact variant property keys (`Size`, `Type`, `State`, `Selected`) and option lists (`Default`, `Hovered`, `Pressed`, `Disabled`). Never invent properties from training memory.

3. **Bottom-Up Dependency Resolution:**
   - Extract base components (atoms, e.g., `SegmentState`, `IconButton`) first $\rightarrow$ Save to `.base/`.
   - Link composite components (molecules/organisms, e.g., `TimescaleNav`, `TimeNavigation`) directly to their base component specs.

---

## 3. Layer 2 — Pixel-Perfect Visual Physics & Token Binding

1. **State Layer Architecture (M3 On-Color Pattern):**
   - Interactive components use a **transparent overlay** (`state-layer`) matching component size, NOT solid color shifts.
   - **On-Color State Token Rule**: State layer color MUST be the on-color of the background it sits on:
     - On `Primary/Bold` background $\rightarrow$ Use `Color/State/OnPrimary` (White overlay: 14% Hover, 18% Pressed).
     - On `Surface / Light` background $\rightarrow$ Use `Color/State/Primary` or `State/Neutral` (8% Hover, 12% Pressed).
     - On `Error/Emphasis` background $\rightarrow$ Use `Color/State/OnError` (16% Hover, 18% Pressed).

2. **Focus Ring Geometry & Global Tokens:**
   - Width: `2px` stroke with `strokeAlign: OUTSIDE`.
   - Geometry: Size = `visualW + 4px` × `visualH + 4px` at `x = -2px, y = -2px`.
   - Corner Radius: Always bind `Radius/xs + 2px` (e.g. 6px + 2px = 8px) or `Radius/full + 2px` on capsules.
   - Global Tokens: Use `Color/Border/Focus` on light surfaces and `Color/Border/Focus/Inverse` on dark/primary surfaces.

3. **Touch Target vs. Safe Area Rules:**
   - **Molecule Level**: Touch target responsibility (≥44×44px hit region) belongs to the parent container/molecule.
   - **Atom Level**: Small atoms get a breathing room padding (e.g., 4px safe area padding) around the visual element without inflating the parent layout unexpectedly.

4. **Per-Component Typography Isolation:**
   - Read `fontFamily` and `fontVariationSettings` per text node individually. Apply `'ROND' 100` ONLY to components whose text nodes explicitly define `ROND: 100` in Figma.

---

## 4. Layer 3 — Machine-Readable AI Behavioral Schema (`componentMetadata`)

When extracting component metadata, generate a structured JavaScript/TypeScript schema following this format:

```typescript
export const componentMetadata = {
  component: {
    name: "ComponentName",
    category: "atoms|molecules|organisms",
    description: "One-line Material Design 3 description from Figma component description field.",
    type: "interactive|display|container|input|navigation"
  },
  
  usage: {
    useCases: ["primary-use-case-1", "secondary-use-case-2"],
    requiredProps: ["requiredPropName"],
    commonPatterns: [
      {
        name: "pattern-name",
        description: "When and how to use this pattern",
        composition: `<Component prop="value"><Child /></Component>`
      }
    ],
    antiPatterns: [
      {
        scenario: "what-not-to-do",
        reason: "why it violates design system rules",
        alternative: "what to do instead"
      }
    ]
  },
  
  composition: {
    slots: {
      "slotName": { required: true, description: "Slot content description" }
    },
    nestedComponents: ["BaseAtom1", "BaseAtom2"],
    commonPartners: ["PartnerComponent1", "PartnerComponent2"],
    parentConstraints: ["Constraint 1", "Constraint 2"]
  },
  
  behavior: {
    states: ["default", "hovered", "pressed", "focused", "disabled"],
    interactions: {
      click: "Exact click handling behavior",
      keyboardNav: "Exact keyboard navigation rules"
    },
    responsive: {
      mobile: "Mobile layout rule",
      desktop: "Desktop layout rule"
    }
  },
  
  accessibility: {
    role: "ARIA role (e.g., tablist, tab, button, switch)",
    keyboardSupport: "Keys supported (e.g., ArrowLeft, ArrowRight, Space, Enter)",
    screenReader: "Screen reader announcement format",
    focusManagement: "Focus strategy (e.g., roving tabindex, visible ring)",
    wcag: "AA"
  },
  
  aiHints: {
    priority: "high|medium|low",
    keywords: ["keyword1", "keyword2", "keyword3"],
    context: "Detailed prompt guidance on when an AI coding agent should select this component.",
    tokenUsage: {
      "role1": "TokenVariable1",
      "role2": "TokenVariable2"
    }
  },

  testingHints: {
    visualRegression: ["Assertion 1", "Assertion 2"],
    unitTests: ["Test case 1", "Test case 2"]
  }
};
```

---

## 5. Layer 4 — Verification & Pre-Publish Checklist

Before completing extraction for any component, verify:
- [ ] **Zero Hardcoded CSS**: Every color, radius, spacing, and font maps to a design system token.
- [ ] **M3 State Layers**: Checked On-Color overlays (`14%` hover / `18%` pressed) on filled components.
- [ ] **Focus Ring Physics**: Verified `visualW+4`, `x=-2px`, `OUTSIDE` stroke, and `Border/Focus` token.
- [ ] **Anti-Patterns Defined**: Minimum 2 explicit anti-patterns preventing AI hallucination.
- [ ] **ARIA Roles Verified**: Explicit `role`, `aria-*` attributes, and keyboard navigation strategy defined.
- [ ] **TypeScript Schema Valid**: Generated valid `componentMetadata` schema matching the Layer 3 contract.
