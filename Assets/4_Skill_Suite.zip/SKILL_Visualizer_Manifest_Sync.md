# Skill: Visualizer Manifest Sync & Interactive Test Bench Generator

## Purpose
Scans `2 Component Spec Schema/`, updates `3 DS Manifest/ds.config.json`, and automatically generates standalone interactive component test bench HTML files (`<Component>_Preview.html`) with live variant control matrices, theme stage toggles, and token footprint bars.

---

## 1. Execution Protocol

1. **Manifest Sync:**
   - Read `3 DS Manifest/ds.config.json`.
   - Scan all `<Component>.md` files in `2 Component Spec Schema/`.
   - Update `components` map and `categories` list in `ds.config.json`.

2. **Interactive Component Test Bench Generation Rule (`<Component>_Preview.html`):**
   For each component, parse variant properties, sub-elements, and token bindings from `<Component>.md` and generate an interactive standalone test bench featuring:
   
   - **Top Control Panel — Figma Component Variant & Property Matrix:**
     - Variant dropdowns (`category`, `size`, `state`) dynamically populated from `componentPropertyDefinitions`.
     - Stage Theme Mode toggle (`Light Theme` | `Dark Theme`) dynamically switching CSS variables (`--md-sys-color-*`, `--flex-sys-color-*`).
     - Sub-element boolean checkboxes (`showOverline`, `showSupportiveLabel`, `showBodyCopy`, `showButtons`, `showCloseButton`, `showLeadingItem`).
     - Display/Width toggles (`380px` fixed vs `100% Fluid`).
     
   - **Center Canvas — Figma Node Render Canvas:**
     - Padded, themed stage canvas rendering the live component.
     - Live JavaScript event listener (`updateCard()`) binding control inputs to real-time DOM updates.
     
   - **Bottom Bar — Token Footprint & Spec Bar:**
     - Live token footprint indicators displaying applied tokens (Corner Radius `28px (sys.shape.corner-extra-large)`, Leading Item Node ID, Button Group specs).
